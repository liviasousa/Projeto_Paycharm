from django.apps import AppConfig


class ControleConfig(AppConfig):
    name = 'controle'
