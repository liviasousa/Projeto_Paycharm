from django.db import models

# Create your models here.
class Produtos(models.Model):
    descricacao = models.CharField(max_length=30)
    valor=models.CharField(max_length=2)
    categorias=models.CharField(max_length=2)
# Parei nessa parte.... Aula10...

#def__str__(self):
 #   return self.produtos