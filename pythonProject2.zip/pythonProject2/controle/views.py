from django.http import JsonResponse

# Create your views here.


def controle(request):
    if request.method == 'GET':
        controle = {'produto': '0', 'venda': '2', 'intensVenda':'0'}
        return JsonResponse(controle)
